package additional_classes;

import java.io.Serializable; import gs.common.model.db.Abstract_Entity;

public class Err_Rec implements Serializable{

  public int err_code = 0;
  public String err_msg = "";
}
