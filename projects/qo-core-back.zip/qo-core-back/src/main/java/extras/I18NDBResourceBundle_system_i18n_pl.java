package extras;

import java.util.Locale;

public class I18NDBResourceBundle_system_i18n_pl extends I18NDBResourceBundle {

  public I18NDBResourceBundle_system_i18n_pl() {
    super("system_bundle", new Locale("pl"));
  }

}
