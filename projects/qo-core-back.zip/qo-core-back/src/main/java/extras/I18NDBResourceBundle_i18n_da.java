package extras;

import java.util.Locale;

public class I18NDBResourceBundle_i18n_da extends I18NDBResourceBundle {

  public I18NDBResourceBundle_i18n_da() {
    super("bundle", new Locale("da"));
  }

}
