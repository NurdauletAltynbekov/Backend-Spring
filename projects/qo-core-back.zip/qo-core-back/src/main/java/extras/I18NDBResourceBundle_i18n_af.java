package extras;

import java.util.Locale;

public class I18NDBResourceBundle_i18n_af extends I18NDBResourceBundle {

  public I18NDBResourceBundle_i18n_af() {
    super("bundle", new Locale("af"));
  }

}
