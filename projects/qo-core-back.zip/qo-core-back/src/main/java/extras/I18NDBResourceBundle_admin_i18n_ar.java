package extras;

import java.util.Locale;

public class I18NDBResourceBundle_admin_i18n_ar extends I18NDBResourceBundle {

  public I18NDBResourceBundle_admin_i18n_ar() {
    super("admin_bundle", new Locale("ar"));
  }

}
