package extras;

import java.util.Locale;

public class I18NDBResourceBundle_admin_i18n_sw extends I18NDBResourceBundle {

  public I18NDBResourceBundle_admin_i18n_sw() {
    super("admin_bundle", new Locale("sw"));
  }

}
