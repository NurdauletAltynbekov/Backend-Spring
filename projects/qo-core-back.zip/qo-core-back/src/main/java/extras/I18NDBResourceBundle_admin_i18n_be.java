package extras;

import java.util.Locale;

public class I18NDBResourceBundle_admin_i18n_be extends I18NDBResourceBundle {

  public I18NDBResourceBundle_admin_i18n_be() {
    super("admin_bundle", new Locale("be"));
  }

}
