package extras;

import java.util.Locale;

public class I18NDBResourceBundle_system_i18n_fa extends I18NDBResourceBundle {

  public I18NDBResourceBundle_system_i18n_fa() {
    super("system_bundle", new Locale("fa"));
  }

}
