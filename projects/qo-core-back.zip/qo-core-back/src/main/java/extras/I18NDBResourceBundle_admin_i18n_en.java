package extras;

import java.util.Locale;

public class I18NDBResourceBundle_admin_i18n_en extends I18NDBResourceBundle {

  public I18NDBResourceBundle_admin_i18n_en() {
    super("admin_bundle", new Locale("en"));
  }

}
