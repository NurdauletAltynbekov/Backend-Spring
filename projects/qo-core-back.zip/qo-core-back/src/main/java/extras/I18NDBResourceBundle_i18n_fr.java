package extras;

import java.util.Locale;

public class I18NDBResourceBundle_i18n_fr extends I18NDBResourceBundle {

  public I18NDBResourceBundle_i18n_fr() {
    super("bundle", new Locale("fr"));
  }

}
