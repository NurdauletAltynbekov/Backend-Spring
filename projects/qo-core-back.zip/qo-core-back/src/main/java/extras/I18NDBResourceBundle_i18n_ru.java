package extras;

import java.util.Locale;

public class I18NDBResourceBundle_i18n_ru extends I18NDBResourceBundle {

  public I18NDBResourceBundle_i18n_ru() {
    super("bundle", new Locale("ru"));
  }

}
