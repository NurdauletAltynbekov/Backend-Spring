package extras;

import java.util.Locale;

public class I18NDBResourceBundle_i18n_uk extends I18NDBResourceBundle {

  public I18NDBResourceBundle_i18n_uk() {
    super("bundle", new Locale("uk"));
  }

}
