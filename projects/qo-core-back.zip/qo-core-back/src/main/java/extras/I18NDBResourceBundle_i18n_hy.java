package extras;

import java.util.Locale;

public class I18NDBResourceBundle_i18n_hy extends I18NDBResourceBundle {

  public I18NDBResourceBundle_i18n_hy() {
    super("bundle", new Locale("hy"));
  }

}
