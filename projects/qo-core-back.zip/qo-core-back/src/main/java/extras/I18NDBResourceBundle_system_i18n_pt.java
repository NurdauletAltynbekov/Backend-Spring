package extras;

import java.util.Locale;

public class I18NDBResourceBundle_system_i18n_pt extends I18NDBResourceBundle {

  public I18NDBResourceBundle_system_i18n_pt() {
    super("system_bundle", new Locale("pt"));
  }

}
