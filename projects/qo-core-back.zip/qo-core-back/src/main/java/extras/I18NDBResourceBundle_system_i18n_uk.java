package extras;

import java.util.Locale;

public class I18NDBResourceBundle_system_i18n_uk extends I18NDBResourceBundle {

  public I18NDBResourceBundle_system_i18n_uk() {
    super("system_bundle", new Locale("uk"));
  }

}
