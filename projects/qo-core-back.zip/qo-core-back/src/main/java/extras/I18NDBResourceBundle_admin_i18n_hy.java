package extras;

import java.util.Locale;

public class I18NDBResourceBundle_admin_i18n_hy extends I18NDBResourceBundle {

  public I18NDBResourceBundle_admin_i18n_hy() {
    super("admin_bundle", new Locale("hy"));
  }

}
