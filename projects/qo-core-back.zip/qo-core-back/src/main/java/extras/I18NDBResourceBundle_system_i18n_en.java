package extras;

import java.util.Locale;

public class I18NDBResourceBundle_system_i18n_en extends I18NDBResourceBundle {

  public I18NDBResourceBundle_system_i18n_en() {
    super("system_bundle", new Locale("en"));
  }

}
