package extras;

import java.util.Locale;

public class I18NDBResourceBundle_admin_i18n_fa extends I18NDBResourceBundle {

  public I18NDBResourceBundle_admin_i18n_fa() {
    super("admin_bundle", new Locale("fa"));
  }

}
