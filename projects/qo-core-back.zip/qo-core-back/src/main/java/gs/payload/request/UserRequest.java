package gs.payload.request;

import javax.validation.constraints.NotBlank;

public class UserRequest {
}
