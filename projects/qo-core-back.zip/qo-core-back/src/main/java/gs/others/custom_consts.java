package gs.others;

public class custom_consts {
  
}
